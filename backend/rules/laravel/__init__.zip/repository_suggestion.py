"""
Repository Suggestion Rule

Suggests extracting database logic to Repositories when controllers use Eloquent directly.
"""
from schemas.facts import Facts
from schemas.metrics import MethodMetrics
from schemas.finding import Finding, Category, Severity
from rules.base import Rule


class RepositorySuggestionRule(Rule):
    """
    Suggests using Repositories for database logic.
    
    Triggers when:
    - Controller methods use Eloquent directly (::where, ::find, etc)
    - Controller methods have high query counts
    """
    
    id = "repository-suggestion"
    name = "Repository Pattern Suggestion"
    description = "Suggests extracting database queries to Repository classes"
    category = Category.ARCHITECTURE
    default_severity = Severity.MEDIUM
    applicable_project_types = ["laravel_api", "laravel_blade", "laravel_inertia_react", "laravel_inertia_vue"]
    
    def analyze(
        self,
        facts: Facts,
        metrics: dict[str, MethodMetrics] | None = None,
    ) -> list[Finding]:
        findings = []
        
        min_query_count = self.get_threshold("min_query_count", 2)
        min_complexity = self.get_threshold("min_complexity", 3)
        
        # Only analyze controllers
        for method in facts.methods:
            # Check if method belongs to a controller
            class_info = next((c for c in facts.controllers if c.name == method.class_name), None)
            if not class_info:
                continue
                
            # Use metrics if available
            method_metrics = metrics.get(method.method_fqn) if metrics else None
            
            # Count queries (either from metrics or raw facts)
            if method_metrics:
                query_count = method_metrics.query_count
                has_business_logic = method_metrics.has_business_logic
                complexity = method_metrics.cyclomatic_complexity
            else:
                # Fallback to direct counting from call sites
                query_count = sum(1 for c in method.call_sites if "::where" in c or "::find" in c or "->get" in c)
                has_business_logic = query_count > 0
                complexity = 1
            
            # Check criteria
            if query_count >= min_query_count and complexity >= min_complexity:
                findings.append(self.create_finding(
                    title=f"Consider Repository Pattern for {method.method_fqn}",
                    file=method.file_path,
                    line_start=method.line_start,
                    line_end=method.line_end,
                    description=(
                        f"Method `{method.name}` contains {query_count} database queries "
                        f"and has a complexity of {complexity}. "
                        f"Direct Eloquent usage in controllers makes testing harder and duplicates logic."
                    ),
                    why_it_matters=(
                        "Repositories abstract data access, making the application easier to test, "
                        "maintain, and change. They strictly separate business logic from data access logic."
                    ),
                    suggested_fix=(
                        f"Extract queries to `{method.class_name.replace('Controller', '')}Repository` "
                        f"and inject it into the controller."
                    ),
                    code_example=self._generate_example(method.class_name),
                    tags=["architecture", "repository", "testing"],
                ))
        
        return findings
    
    def _generate_example(self, controller_name: str) -> str:
        """Generate before/after example."""
        model_name = controller_name.replace("Controller", "")
        repo_name = f"{model_name}Repository"
        variable_name = model_name.lower()
        
        return f"""// Before: Direct Eloquent in Controller
public function index()
{{
    $active = {model_name}::where('status', 'active')
        ->orderBy('created_at', 'desc')
        ->get();
    return view('index', compact('active'));
}}

// After: Using Repository
protected ${variable_name}Repo;

public function __construct({repo_name} ${variable_name}Repo)
{{
    $this->{variable_name}Repo = ${variable_name}Repo;
}}

public function index()
{{
    $active = $this->{variable_name}Repo->getActiveUsers();
    return view('index', compact('active'));
}}"""
