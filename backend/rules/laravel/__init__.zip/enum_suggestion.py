"""
Enum Suggestion Rule
Detects repeated string literals that should be PHP enums.
"""
from collections import defaultdict
from schemas.facts import Facts, StringLiteral
from schemas.metrics import MethodMetrics
from schemas.finding import Finding, Category, Severity
from rules.base import Rule


class EnumSuggestionRule(Rule):
    """
    Detects repeated string literals that are enum candidates.
    
    Common patterns:
    - Status values: "pending", "approved", "rejected"
    - Types: "admin", "user", "guest"
    - States: "draft", "published", "archived"
    """
    
    id = "enum-suggestion"
    name = "Enum Suggestion"
    description = "Suggests creating PHP enums for repeated string literals"
    category = Category.DRY
    default_severity = Severity.LOW
    applicable_project_types = [
        "laravel_blade",
        "laravel_inertia_react",
        "laravel_inertia_vue",
        "laravel_api",
        "laravel_livewire",
    ]
    
    # Common enum patterns
    ENUM_PATTERNS = {
        "status": ["pending", "approved", "rejected", "cancelled", "completed", "active", "inactive"],
        "role": ["admin", "user", "guest", "moderator", "editor", "viewer"],
        "type": ["primary", "secondary", "default", "danger", "warning", "success", "info"],
        "state": ["draft", "published", "archived", "deleted", "hidden"],
        "priority": ["low", "medium", "high", "urgent", "critical"],
        
        # Game-specific patterns
        "game_status": ["waiting", "in_progress", "finished", "paused", "cancelled", "staging"],
        "game_phase": ["day", "night", "discussion", "voting", "action", "setup", "reveal"],
        "player_status": ["alive", "dead", "spectator", "disconnected", "eliminated"],
        "werewolf_role": ["villager", "wolf", "doc", "seer", "witch", "hunter", "cupid", "amor", "bodyguard", "lycan"],
        "action_type": ["vote", "kill", "save", "poison", "check", "protect", "link"],
    }
    
    def analyze(
        self,
        facts: Facts,
        metrics: dict[str, MethodMetrics] | None = None,
    ) -> list[Finding]:
        findings = []
        
        min_occurrences = self.get_threshold("min_occurrences", 3)
        
        # Analyze tracked string literals
        for literal in facts.string_literals:
            if len(literal.occurrences) >= min_occurrences:
                # Only recommend enums for values that look domain-like.
                # Avoid noise from infra/config tokens ("redis", "host", "port", ...).
                if literal.is_enum_candidate or self._is_enum_candidate(literal.value):
                    findings.append(self._create_finding(literal))
        
        # Also look for patterns across string literals
        grouped_findings = self._find_enum_groups(facts.string_literals, min_occurrences)
        findings.extend(grouped_findings)
        
        return findings
    
    def _is_enum_candidate(self, value: str) -> bool:
        """Check if a string value looks like an enum candidate."""
        value_lower = value.lower()
        
        # Check against known patterns
        for pattern_values in self.ENUM_PATTERNS.values():
            if value_lower in pattern_values:
                return True

        # Intentionally conservative: without AST usage context, generic heuristics
        # create too many false positives (config keys, cache drivers, column names).
        return False
    
    def _find_enum_groups(
        self,
        literals: list[StringLiteral],
        min_occurrences: int,
    ) -> list[Finding]:
        """Find groups of related string literals that form an enum."""
        findings = []
        
        # Group by pattern
        for pattern_name, pattern_values in self.ENUM_PATTERNS.items():
            matching_literals = []
            all_occurrences = []
            
            for literal in literals:
                if literal.value.lower() in pattern_values:
                    matching_literals.append(literal.value)
                    all_occurrences.extend(literal.occurrences)
            
            # If we found multiple related values
            if len(set(matching_literals)) >= 2 and len(all_occurrences) >= min_occurrences:
                # Find most common file for the finding
                if all_occurrences:
                    file_path = all_occurrences[0][0]
                    line = all_occurrences[0][1]
                    
                    findings.append(self.create_finding(
                        title=f"Create {pattern_name.title()}Enum for related string literals",
                        file=file_path,
                        line_start=line,
                        description=(
                            f"Found related string literals that should be a PHP enum: "
                            f"{', '.join(sorted(set(matching_literals)))}. "
                            f"These appear {len(all_occurrences)} times across the codebase."
                        ),
                        why_it_matters=(
                            "Magic strings are error-prone and hard to refactor. "
                            "PHP 8.1+ enums provide type safety, IDE autocompletion, "
                            "and make invalid states impossible."
                        ),
                        suggested_fix=self._generate_enum_suggestion(
                            pattern_name,
                            list(set(matching_literals)),
                        ),
                        code_example=self._generate_enum_example(
                            pattern_name,
                            list(set(matching_literals)),
                        ),
                        tags=["enum", "dry", "type-safety"],
                    ))
        
        return findings
    
    def _create_finding(self, literal: StringLiteral) -> Finding:
        """Create finding for a single repeated literal."""
        first_occurrence = literal.occurrences[0] if literal.occurrences else ("", 0)
        
        enum_name = literal.suggested_enum_name or self._suggest_enum_name(literal.value)
        
        return self.create_finding(
            title=f"Consider enum for repeated string '{literal.value}'",
            file=first_occurrence[0],
            line_start=first_occurrence[1],
            description=(
                f"The string '{literal.value}' appears {len(literal.occurrences)} times. "
                f"Consider creating a PHP enum to ensure type safety."
            ),
            why_it_matters=(
                "Repeated string literals are a maintenance burden. "
                "If you need to change the value, you must find all occurrences. "
                "Enums provide compile-time safety and IDE support."
            ),
            suggested_fix=f"Create `App\\Enums\\{enum_name}` enum with this value",
            code_example=self._generate_single_enum_example(literal.value, enum_name),
            related_files=[occ[0] for occ in literal.occurrences[:5]],
            tags=["enum", "dry"],
        )
    
    def _suggest_enum_name(self, value: str) -> str:
        """Suggest an enum class name based on the value."""
        for pattern_name, pattern_values in self.ENUM_PATTERNS.items():
            if value.lower() in pattern_values:
                return f"{pattern_name.title()}Enum"
        
        return "StatusEnum"
    
    def _generate_enum_suggestion(self, pattern_name: str, values: list[str]) -> str:
        """Generate fix suggestion for enum group."""
        enum_name = f"{pattern_name.title()}Enum"
        return (
            f"1. Create `app/Enums/{enum_name}.php`\n"
            f"2. Add cases: {', '.join(values)}\n"
            f"3. Replace string literals with `{enum_name}::CaseName`\n"
            f"4. Update database columns to use `->string()` with enum casting"
        )
    
    def _generate_enum_example(self, pattern_name: str, values: list[str]) -> str:
        """Generate code example for enum group."""
        enum_name = f"{pattern_name.title()}"
        cases = "\n    ".join(f"case {v.upper().replace('-', '_')} = '{v}';" for v in values)
        
        return f"""// app/Enums/{enum_name}.php
enum {enum_name}: string
{{
    {cases}
}}

// Usage in Model
class Order extends Model
{{
    protected $casts = [
        '{pattern_name}' => {enum_name}::class,
    ];
}}

// Usage in code
$order->{pattern_name} = {enum_name}::{values[0].upper().replace('-', '_')};
if ($order->{pattern_name} === {enum_name}::{values[0].upper().replace('-', '_')}) {{ ... }}"""
    
    def _generate_single_enum_example(self, value: str, enum_name: str) -> str:
        """Generate example for single value."""
        case_name = value.upper().replace("-", "_").replace(" ", "_")
        
        return f"""// app/Enums/{enum_name}.php
enum {enum_name}: string
{{
    case {case_name} = '{value}';
    // Add other related cases
}}

// Before
$model->status = '{value}';

// After
$model->status = {enum_name}::{case_name};"""
