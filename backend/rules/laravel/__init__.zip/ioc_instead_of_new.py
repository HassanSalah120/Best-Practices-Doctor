"""
IoC Instead Of `new` Rule
Suggests dependency injection instead of instantiating services in controllers.
"""
from schemas.facts import Facts, MethodInfo
from schemas.metrics import MethodMetrics
from schemas.finding import Finding, Category, Severity
from rules.base import Rule


class IocInsteadOfNewRule(Rule):
    """
    Flags `new SomeService()` usage in controllers.

    In Laravel, prefer injecting dependencies (constructor/method injection) so:
    - code is testable/mocked
    - dependencies are explicit
    - you can swap implementations via bindings
    """

    id = "ioc-instead-of-new"
    name = "Prefer IoC Over new"
    description = "Suggests injecting dependencies instead of instantiating them in controllers"
    category = Category.ARCHITECTURE
    default_severity = Severity.MEDIUM
    applicable_project_types = [
        "laravel_blade",
        "laravel_inertia_react",
        "laravel_inertia_vue",
        "laravel_api",
        "laravel_livewire",
    ]

    _ALLOWLIST = {
        "DateTime",
        "DateTimeImmutable",
        "Exception",
        "RuntimeException",
        "InvalidArgumentException",
    }

    def analyze(
        self,
        facts: Facts,
        metrics: dict[str, MethodMetrics] | None = None,
    ) -> list[Finding]:
        findings: list[Finding] = []
        max_news = self.get_threshold("max_instantiations", 0)

        controller_names = {c.name for c in facts.controllers}

        for method in facts.methods:
            if method.class_name not in controller_names:
                continue
            if method.name.startswith("__"):
                continue

            inst = [c for c in (method.instantiations or []) if c.split("\\")[-1] not in self._ALLOWLIST]
            if not inst:
                continue
            if len(inst) <= max_news:
                continue

            findings.append(self._create_finding(method, inst))

        return findings

    def _create_finding(self, method: MethodInfo, instantiations: list[str]) -> Finding:
        inst_list = ", ".join(instantiations[:5]) + ("..." if len(instantiations) > 5 else "")

        return self.create_finding(
            title="Prefer dependency injection over `new` in controllers",
            context=method.method_fqn,
            file=method.file_path,
            line_start=method.line_start,
            line_end=method.line_end,
            description=(
                f"Method `{method.method_fqn}` instantiates dependencies directly: {inst_list}. "
                "In controllers, this usually indicates hidden dependencies."
            ),
            why_it_matters=(
                "Direct instantiation makes code harder to test and refactor. "
                "Dependency injection (via Laravel's IoC container) keeps dependencies explicit "
                "and enables swapping implementations."
            ),
            suggested_fix=(
                "1. Move object creation to the container (bind interface to implementation)\n"
                "2. Inject the dependency via constructor or method injection\n"
                "3. Use interfaces for services/repositories when appropriate"
            ),
            code_example=(
                "// Before\n"
                "public function store(Request $request)\n"
                "{\n"
                "    $svc = new UserService();\n"
                "    return $svc->create($request->all());\n"
                "}\n\n"
                "// After (method injection)\n"
                "public function store(Request $request, UserService $svc)\n"
                "{\n"
                "    return $svc->create($request->all());\n"
                "}\n"
            ),
            tags=["laravel", "ioc", "di", "testing"],
        )

