"""
N+1 Risk Rule

Detects likely lazy-loaded relation access inside iteration constructs.

Tree-sitter is the source of truth: the FactsBuilder extracts RelationAccess facts
from AST nodes (foreach + collection ->each/map callbacks). This rule only reads facts.
"""
from schemas.facts import Facts, RelationAccess, QueryUsage
from schemas.metrics import MethodMetrics
from schemas.finding import Finding, Category, Severity
from rules.base import Rule


class NPlusOneRiskRule(Rule):
    """
    Flags relation access in loops as a likely N+1 performance issue.

    This is heuristic-based because we don't do full type inference:
    - We assume `$item->relation` in an iteration is a relation access, not a scalar property.
    - We increase confidence when the surrounding method contains queries without eager loading.
    """

    id = "n-plus-one-risk"
    name = "N+1 Risk Detection"
    description = "Detects likely lazy-loaded relation access in loops (N+1 risk)"
    category = Category.PERFORMANCE
    default_severity = Severity.HIGH
    applicable_project_types = [
        "laravel_blade",
        "laravel_inertia_react",
        "laravel_inertia_vue",
        "laravel_api",
        "laravel_livewire",
    ]

    def analyze(
        self,
        facts: Facts,
        metrics: dict[str, MethodMetrics] | None = None,
    ) -> list[Finding]:
        findings: list[Finding] = []

        # Index queries by method for confidence tuning.
        q_by_method: dict[tuple[str, str], list[QueryUsage]] = {}
        for q in facts.queries:
            q_by_method.setdefault((q.file_path, q.method_name), []).append(q)

        # Group accesses to avoid noisy duplicates.
        grouped: dict[tuple[str, str, str, str], list[RelationAccess]] = {}
        for ra in facts.relation_accesses:
            key = (
                ra.file_path,
                ra.method_name,
                ra.relation,
                ra.loop_kind,
            )
            grouped.setdefault(key, []).append(ra)

        for (file_path, method_name, relation, loop_kind), ras in grouped.items():
            sample = ras[0]
            line_start = min(r.line_number for r in ras)
            occurrences = len(ras)

            qs = q_by_method.get((file_path, method_name), [])
            has_any_query = len(qs) > 0
            has_any_eager = any(q.has_eager_loading for q in qs)

            confidence = 0.55
            if has_any_query and not has_any_eager:
                confidence = 0.75
            elif has_any_query and has_any_eager:
                confidence = 0.6

            ctx_cls = sample.class_fqcn or ""
            ctx = f"{ctx_cls}::{method_name}:{sample.base_var}->{relation}:{loop_kind}"

            findings.append(
                self.create_finding(
                    title="Potential N+1: lazy-loaded relation inside iteration",
                    context=ctx,
                    file=file_path,
                    line_start=line_start,
                    description=(
                        f"Detected `{sample.base_var}->{relation}` accessed inside `{loop_kind}`. "
                        "In Laravel/Eloquent, accessing relations inside a loop often triggers one query per item (N+1). "
                        + (f"({occurrences} occurrence(s) detected.)" if occurrences > 1 else "")
                    ),
                    why_it_matters=(
                        "N+1 query patterns can massively slow down pages and APIs by multiplying database round-trips. "
                        "The fix is usually to eager load the relation or restructure the data access so it runs once."
                    ),
                    suggested_fix=(
                        "1. Eager load the relation before iterating: `Model::with('relation')->...->get()`\n"
                        "2. If iterating an existing collection, consider `load('relation')` before the loop\n"
                        "3. If you need aggregates, use `withCount()` / `withSum()` instead of per-item queries\n"
                        "4. Confirm with Telescope/Debugbar query count"
                    ),
                    code_example=(
                        "// Before\n"
                        "$users = User::all();\n"
                        "foreach ($users as $user) {\n"
                        "    $user->posts; // lazy loads per user\n"
                        "}\n\n"
                        "// After\n"
                        "$users = User::with('posts')->get();\n"
                    ),
                    confidence=confidence,
                    tags=["performance", "n+1", "eloquent", "eager-loading"],
                )
            )

        return findings

