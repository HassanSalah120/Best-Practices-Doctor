"""
DTO Suggestion Rule

Flags large associative arrays being passed around between layers and suggests DTOs.
"""
from schemas.facts import Facts, AssocArrayLiteral
from schemas.metrics import MethodMetrics
from schemas.finding import Finding, Category, Severity
from rules.base import Rule


class DtoSuggestionRule(Rule):
    """
    Suggest using DTOs instead of passing large associative arrays between layers.

    This rule uses AST-extracted facts (AssocArrayLiteral). It intentionally ignores:
    - Validation rule arrays (`validate`, `Validator::make`)
    - View/response payload arrays (`view`, `json`) where arrays are expected
    """

    id = "dto-suggestion"
    name = "DTO Suggestion"
    description = "Suggests DTOs when large associative arrays are used as data carriers"
    category = Category.MAINTAINABILITY
    default_severity = Severity.MEDIUM
    applicable_project_types = [
        "laravel_blade",
        "laravel_inertia_react",
        "laravel_inertia_vue",
        "laravel_api",
        "laravel_livewire",
        "native_php",
        "php_mvc",
    ]

    def analyze(
        self,
        facts: Facts,
        metrics: dict[str, MethodMetrics] | None = None,
    ) -> list[Finding]:
        findings: list[Finding] = []

        min_keys = int(self.get_threshold("min_keys", 6))
        ignore_targets = {"validate", "make", "json", "view", "compact"}

        grouped: dict[tuple[str, str, str, str | None], list[AssocArrayLiteral]] = {}
        for a in facts.assoc_arrays:
            if a.key_count < min_keys:
                continue
            if a.file_path.startswith("config/"):
                continue
            if a.target and a.target in ignore_targets:
                continue

            key = (a.file_path, a.method_name, a.used_as, a.target)
            grouped.setdefault(key, []).append(a)

        for (file_path, method_name, used_as, target), arrs in grouped.items():
            sample = arrs[0]
            line_start = min(a.line_number for a in arrs)
            max_keys = max(a.key_count for a in arrs)
            count = len(arrs)

            ctx_cls = sample.class_fqcn or ""
            ctx = f"{ctx_cls}::{method_name}:{used_as}:{target or ''}:{max_keys}"

            tgt = target or "data flow"
            findings.append(
                self.create_finding(
                    title="Consider using a DTO instead of a large associative array",
                    context=ctx,
                    file=file_path,
                    line_start=line_start,
                    description=(
                        f"Found {count} associative array literal(s) with {max_keys} key(s) used as `{used_as}` "
                        f"(target: `{tgt}`). Large arrays passed between layers tend to become untyped DTOs."
                    ),
                    why_it_matters=(
                        "Large associative arrays are easy to accidentally break (typos, missing keys) and hard to refactor. "
                        "DTOs (or Value Objects) provide explicit structure, type-safety, and improve readability."
                    ),
                    suggested_fix=(
                        "1. Introduce a DTO class (e.g., `UserPayload`, `OrderData`)\n"
                        "2. Replace array creation with `new Dto(...)` or a named constructor\n"
                        "3. Pass the DTO between layers instead of raw arrays\n"
                        "4. Add DTO validation/coercion at boundaries (request -> DTO)"
                    ),
                    code_example=(
                        "// Before\n"
                        "$payload = [\n"
                        "  'user_id' => $id,\n"
                        "  'email' => $email,\n"
                        "  // ...\n"
                        "];\n"
                        "$service->handle($payload);\n\n"
                        "// After\n"
                        "$payload = new UserPayload(userId: $id, email: $email);\n"
                        "$service->handle($payload);\n"
                    ),
                    tags=["maintainability", "dto", "typing", "architecture"],
                    confidence=0.7,
                )
            )

        return findings

