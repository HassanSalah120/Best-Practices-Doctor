"""Laravel rules init."""
from .fat_controller import FatControllerRule
from .missing_form_request import MissingFormRequestRule
from .service_extraction import ServiceExtractionRule
from .enum_suggestion import EnumSuggestionRule
from .blade_queries import BladeQueriesRule
from .repository_suggestion import RepositorySuggestionRule
from .contract_suggestion import ContractSuggestionRule
from .custom_exception_suggestion import CustomExceptionSuggestionRule
from .eager_loading import EagerLoadingRule
from .n_plus_one_risk import NPlusOneRiskRule
from .env_usage import EnvOutsideConfigRule
from .ioc_instead_of_new import IocInsteadOfNewRule
from .controller_query_direct import ControllerQueryDirectRule
from .controller_business_logic import ControllerBusinessLogicRule
from .controller_validation_inline import ControllerInlineValidationRule
from .dto_suggestion import DtoSuggestionRule
from .mass_assignment_risk import MassAssignmentRiskRule
from .action_class_suggestion import ActionClassSuggestionRule
from .massive_model import MassiveModelRule
from .unsafe_file_upload import UnsafeFileUploadRule

__all__ = [
    "FatControllerRule",
    "MissingFormRequestRule",
    "ServiceExtractionRule",
    "EnumSuggestionRule",
    "BladeQueriesRule",
    "RepositorySuggestionRule",
    "ContractSuggestionRule",
    "CustomExceptionSuggestionRule",
    "EagerLoadingRule",
    "NPlusOneRiskRule",
    "EnvOutsideConfigRule",
    "IocInsteadOfNewRule",
    "ControllerQueryDirectRule",
    "ControllerBusinessLogicRule",
    "ControllerInlineValidationRule",
    "DtoSuggestionRule",
    "MassAssignmentRiskRule",
    "ActionClassSuggestionRule",
    "MassiveModelRule",
    "UnsafeFileUploadRule",
]
